import AuthForm from "@/components/AuthForm";

const SignIn = () => <AuthForm type="sign-in" />;

export default SignIn;
